# django-crud-mysql-connector
Simple CRUD 
