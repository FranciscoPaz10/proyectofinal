from django.apps import AppConfig


class SimplewebConfig(AppConfig):
    name = 'simpleweb'
