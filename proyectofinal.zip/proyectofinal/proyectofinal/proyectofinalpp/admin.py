from django.contrib import admin
from .models import Marca, Producto, Compra, Caja, Persona, TipoPersona, Venta, DetalleVenta, DetalleCompra
# Register your models here.
admin.site.register(Marca)
admin.site.register(Producto)
admin.site.register(Compra)
admin.site.register(Caja)
admin.site.register(Persona)
admin.site.register(TipoPersona)
admin.site.register(Venta)
admin.site.register(DetalleVenta)
admin.site.register(DetalleCompra)

