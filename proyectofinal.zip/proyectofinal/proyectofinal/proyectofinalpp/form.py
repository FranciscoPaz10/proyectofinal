from django import forms
from .models import Caja, Venta, Persona, Compra,DetalleCompra, Producto, Marca, DetalleVenta, TipoPersona





class CajaForm(forms.ModelForm):
    class Meta:
        model = Caja
        fields = ['Saldo', 'Fecha_Apertura', 'Fecha_Cierre', 'id_Tipo']
        labels = {
            'Saldo': 'Saldo',
            'Fecha_Apertura': 'Fecha de Apertura',
            'Fecha_Cierre': 'Fecha de Cierre',
            'id_Tipo': 'Tipo de Caja',
        }
        widgets = {
            'Fecha_Apertura': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'Fecha_Cierre': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }


class VentaForm(forms.ModelForm):
    class Meta:
        model = Venta
        fields = ['Fecha_venta', 'Total_venta', 'Met_pagos', 'id_Persona', 'idCajas']
        widgets = {
            'Fecha_venta': forms.TextInput(attrs={'type': 'date'}),
        }
        labels = {
            'Fecha_venta': 'Fecha de Venta',
            'Total_venta': 'Total de Venta',
            'Met_pagos': 'Método de Pago',
            'id_Persona': 'Persona',
            'idCajas': 'Caja',
        }
        
class PersonaForm(forms.ModelForm):
    class Meta:
        model = Persona
        fields = ['Nombre', 'Apellido', 'Telefono', 'Correo', 'id_Tipo']
        labels = {
            'Nombre': 'Nombre',
            'Apellido': 'Apellido',
            'Telefono': 'Teléfono',
            'Correo': 'Correo Electrónico',
            'id_Tipo': 'Tipo de Persona',
        }
        
class CompraForm(forms.ModelForm):
    class Meta:
        model = Compra
        fields = ['Fecha_Compra', 'Total_Compra', 'id_Persona', 'idCajas']
        labels = {
            'Fecha_Compra': 'Fecha de Compra',
            'Total_Compra': 'Total de la Compra',
            'id_Persona': 'ID de la Persona',
            'idCajas': 'ID de la Caja',
        }
        
class DetalleCompraForm(forms.ModelForm):
    class Meta:
        model = DetalleCompra
        fields = ['idCompra', 'idProducto', 'Cant_Comprada', 'Prec_uni']
        labels = {
            'idCompra': 'ID de Compra',
            'idProducto': 'ID de Producto',
            'Cant_Comprada': 'Cantidad Comprada',
            'Prec_uni': 'Precio Unitario',
        }
        

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['Nombre', 'Descripcion', 'Precio', 'Stock', 'idMarca']
        labels = {
            'Nombre': 'Nombre del Producto',
            'Descripcion': 'Descripción',
            'Precio': 'Precio',
            'Stock': 'Stock Disponible',
            'idMarca': 'ID de la Marca',
        }

class MarcaForm(forms.ModelForm):
    class Meta:
        model = Marca
        fields = ['Nombre']
        labels = {
            'Nombre': 'Nombre de la Marca',
        }


class DetalleVentaForm(forms.ModelForm):
    class Meta:
        model = DetalleVenta
        fields = ['idVentas', 'idProducto', 'Cant_vendida', 'Prec_uni']
        labels = {
            'idVentas': 'ID de la Venta',
            'idProducto': 'ID del Producto',
            'Cant_vendida': 'Cantidad Vendida',
            'Prec_uni': 'Precio Unitario',
        }

class TipoPersonaForm(forms.ModelForm):
    class Meta:
        model = TipoPersona
        fields = ['Tipo']
        labels = {
            'Tipo': 'Tipo de Persona',
        }
