from django.db import models

class Caja(models.Model):
    idCajas = models.AutoField(primary_key=True)
    Saldo = models.FloatField()
    Fecha_Apertura = models.DateTimeField()
    Fecha_Cierre = models.DateTimeField(null=True, blank=True)
    id_Tipo = models.IntegerField()

    def __str__(self):
        return f'Caja {self.idCajas}'



class Compra(models.Model):
    idCompra = models.AutoField(primary_key=True)
    Fecha_Compra = models.CharField(max_length=45)
    Total_Compra = models.CharField(max_length=45)
    id_Persona = models.IntegerField()
    idCajas = models.IntegerField()

    def __str__(self):
        return f'Compra {self.idCompra}'


class Persona(models.Model):
    id_Persona = models.AutoField(primary_key=True)
    Nombre = models.CharField(max_length=45)
    Apellido = models.CharField(max_length=45)
    Telefono = models.CharField(max_length=45)
    Correo = models.CharField(max_length=45)
    id_Tipo = models.IntegerField()

    def __str__(self):
        return self.Nombre
    
class TipoPersona(models.Model):
    id_Tipo = models.AutoField(primary_key=True)
    Tipo = models.CharField(max_length=45)

    def __str__(self):
        return self.Tipo
    
class Producto(models.Model):
    idProducto = models.AutoField(primary_key=True)
    Nombre = models.CharField(max_length=45)
    Descripcion = models.CharField(max_length=45)
    Precio = models.FloatField()
    Stock = models.FloatField()
    idMarca = models.IntegerField()

    def __str__(self):
        return self.Nombre
    
class Marca(models.Model):
    idMarca = models.AutoField(primary_key=True)
    Nombre = models.CharField(max_length=45)

    def __str__(self):
        return self.Nombre
    
class Venta(models.Model):
    idVentas = models.AutoField(primary_key=True)
    Fecha_venta = models.CharField(max_length=45)
    Total_venta = models.FloatField()
    Met_pagos = models.CharField(max_length=45)
    id_Persona = models.IntegerField()
    idCajas = models.IntegerField()

    def __str__(self):
        return f'Venta {self.idVentas}'
    
class DetalleVenta(models.Model):
    id_DetVta = models.AutoField(primary_key=True)
    idVentas = models.IntegerField()
    idProducto = models.IntegerField()
    Cant_vendida = models.CharField(max_length=45)
    Prec_uni = models.FloatField()

    def __str__(self):
        return f'Detalle Venta {self.id_DetVta}'
    
class DetalleCompra(models.Model):
    id_DetCompra = models.AutoField(primary_key=True)
    idCompra = models.IntegerField()
    idProducto = models.IntegerField()
    Cant_Comprada = models.CharField(max_length=45)
    Prec_uni = models.IntegerField()

    def __str__(self):
        return f'Detalle Compra {self.id_DetCompra}'