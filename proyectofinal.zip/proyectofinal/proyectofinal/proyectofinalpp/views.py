from django.shortcuts import render
from django.shortcuts import render, get_object_or_404, redirect
from .form import CajaForm, VentaForm,PersonaForm, CompraForm, DetalleCompraForm, ProductoForm, MarcaForm, DetalleVentaForm, TipoPersonaForm
from .models import Venta,Persona,Compra, DetalleCompra, Producto, Marca, DetalleVenta, Caja, TipoPersona
import mysql.connector as mcdb
from django.contrib.auth.decorators import login_required


conn = mcdb.connect(host="proyectofinal-mysql-1", user="root", passwd="example", database='Prueba')
print('Successfully connected to database')



@login_required
def inicio(request):
    return render(request, 'inicio.html')

# Lista de todas las cajas
def lista_cajas(request):
    cajas = Caja.objects.all()
    return render(request, 'cajas/lista_cajas.html', {'cajas': cajas})

# Crear una nueva caja
def crear_caja(request):
    if request.method == 'POST':
        form = CajaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_cajas')
    else:
        form = CajaForm()
    return render(request, 'cajas/crear_caja.html', {'form': form})

# Actualizar una caja existente
def actualizar_caja(request, id):
    caja = get_object_or_404(Caja, idCajas=id)
    if request.method == 'POST':
        form = CajaForm(request.POST, instance=caja)
        if form.is_valid():
            form.save()
            return redirect('lista_cajas')
    else:
        form = CajaForm(instance=caja)
    return render(request, 'cajas/crear_caja.html', {'form': form})

# Eliminar una caja
def eliminar_caja(request, id):
    caja = get_object_or_404(Caja, idCajas=id)
    if request.method == 'POST':
        caja.delete()
        return redirect('lista_cajas')
    return render(request, 'cajas/eliminar_caja.html', {'caja': caja})

def lista_ventas(request):
    ventas = Venta.objects.all()
    return render(request, 'ventas/lista_venta.html', {'ventas': ventas})
def crear_venta(request):
    if request.method == 'POST':
        form = VentaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_ventas')
    else:
        form = VentaForm()
    return render(request, 'ventas/crear_venta.html', {'form': form})

def actualizar_venta(request, id):
    venta = get_object_or_404(Venta, idVentas=id)
    if request.method == 'POST':
        form = VentaForm(request.POST, instance=venta)
        if form.is_valid():
            form.save()
            return redirect('lista_ventas')
    else:
        form = VentaForm(instance=venta)
    return render(request, 'ventas/actualizar_venta.html', {'form': form})


def eliminar_venta(request, id):
    venta = get_object_or_404(Venta, idVentas=id)
    if request.method == 'POST':
        venta.delete()
        return redirect('lista_ventas')
    return render(request, 'ventas/eliminar_venta.html', {'venta': venta})

def lista_personas(request):
    personas = Persona.objects.all()
    return render(request, 'personas/lista_personas.html', {'personas': personas})

def crear_persona(request):
    if request.method == 'POST':
        form = PersonaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_personas')
    else:
        form = PersonaForm()
    return render(request, 'personas/crear_persona.html', {'form': form})

def eliminar_persona(request, id):
    persona = get_object_or_404(Persona, id_Persona=id)
    if request.method == 'POST':
        persona.delete()
        return redirect('lista_personas')
    return render(request, 'personas/eliminar_persona.html', {'persona': persona})

def actualizar_persona(request, id):
    persona = get_object_or_404(Persona, id_Persona=id)
    if request.method == 'POST':
        form = PersonaForm(request.POST, instance=persona)
        if form.is_valid():
            form.save()
            return redirect('lista_personas')
    else:
        form = PersonaForm(instance=persona)
    return render(request, 'personas/actualizar_persona.html', {'form': form})

def inicio(request):
    return render(request, 'inicio.html')

def lista_compras(request):
    compras = Compra.objects.all()
    return render(request, 'compras/lista_compras.html', {'compras': compras})

def crear_compra(request):
    if request.method == 'POST':
        form = CompraForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_compras')
    else:
        form = CompraForm()
    return render(request, 'compras/crear_compra.html', {'form': form})

def actualizar_compra(request, id):
    compra = get_object_or_404(Compra, idCompra=id)
    if request.method == 'POST':
        form = CompraForm(request.POST, instance=compra)
        if form.is_valid():
            form.save()
            return redirect('lista_compras')
    else:
        form = CompraForm(instance=compra)
    return render(request, 'compras/crear_compra.html', {'form': form})

def eliminar_compra(request, id):
    compra = get_object_or_404(Compra, idCompra=id)
    if request.method == 'POST':
        compra.delete()
        return redirect('lista_compras')
    return render(request, 'compras/eliminar_compra.html', {'compra': compra})



def lista_detalles_compras(request):
    detalles = DetalleCompra.objects.all()
    return render(request, 'detalles_compras/lista_detalles_compras.html', {'detalles': detalles})

def detalle_detalle_compra(request, id):
    detalle = get_object_or_404(DetalleCompra, id_DetCompra=id)
    return render(request, 'detalles_compras/detalle_detalle_compra.html', {'detalle': detalle})

def crear_detalle_compra(request):
    if request.method == 'POST':
        form = DetalleCompraForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_detalles_compras')
    else:
        form = DetalleCompraForm()
    return render(request, 'detalles_compras/crear_detalle_compra.html', {'form': form})

def actualizar_detalle_compra(request, id):
    detalle = get_object_or_404(DetalleCompra, id_DetCompra=id)
    if request.method == 'POST':
        form = DetalleCompraForm(request.POST, instance=detalle)
        if form.is_valid():
            form.save()
            return redirect('lista_detalles_compras')
    else:
        form = DetalleCompraForm(instance=detalle)
    return render(request, 'detalles_compras/crear_detalle_compra.html', {'form': form})

def eliminar_detalle_compra(request, id):
    detalle = get_object_or_404(DetalleCompra, id_DetCompra=id)
    if request.method == 'POST':
        detalle.delete()
        return redirect('lista_detalles_compras')
    return render(request, 'detalles_compras/eliminar_detalle_compra.html', {'detalle': detalle})


def lista_productos(request):
    productos = Producto.objects.all()
    return render(request, 'productos/lista_productos.html', {'productos': productos})

def crear_producto(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_productos')
    else:
        form = ProductoForm()
    return render(request, 'productos/crear_producto.html', {'form': form})

def actualizar_producto(request, id):
    producto = get_object_or_404(Producto, idProducto=id)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('lista_productos')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'productos/crear_producto.html', {'form': form})

def eliminar_producto(request, id):
    producto = get_object_or_404(Producto, idProducto=id)
    if request.method == 'POST':
        producto.delete()
        return redirect('lista_productos')
    return render(request, 'productos/eliminar_producto.html', {'producto': producto})

def lista_marcas(request):
    marcas = Marca.objects.all()
    return render(request, 'marcas/lista_marcas.html', {'marcas': marcas})

def crear_marca(request):
    if request.method == 'POST':
        form = MarcaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_marcas')
    else:
        form = MarcaForm()
    return render(request, 'marcas/crear_marca.html', {'form': form})

def actualizar_marca(request, id):
    marca = get_object_or_404(Marca, idMarca=id)
    if request.method == 'POST':
        form = MarcaForm(request.POST, instance=marca)
        if form.is_valid():
            form.save()
            return redirect('lista_marcas')
    else:
        form = MarcaForm(instance=marca)
    return render(request, 'marcas/crear_marca.html', {'form': form})

def eliminar_marca(request, id):
    marca = get_object_or_404(Marca, idMarca=id)
    if request.method == 'POST':
        marca.delete()
        return redirect('lista_marcas')
    return render(request, 'marcas/eliminar_marca.html', {'marca': marca})
def lista_detalle_ventas(request):
    detalles_ventas = DetalleVenta.objects.all()
    return render(request, 'detalle_ventas/lista_detalle_ventas.html', {'detalles_ventas': detalles_ventas})


# Lista de todos los detalles de ventas
def lista_detalles_ventas(request):
    detalles_ventas = DetalleVenta.objects.all()
    return render(request, 'detalles_ventas/lista_detalles_ventas.html', {'detalles_ventas': detalles_ventas})

# Crear un nuevo detalle de venta
def crear_detalle_venta(request):
    if request.method == 'POST':
        form = DetalleVentaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_detalles_ventas')
    else:
        form = DetalleVentaForm()
    return render(request, 'detalles_ventas/crear_detalle_venta.html', {'form': form})

# Actualizar un detalle de venta existente
def actualizar_detalle_venta(request, id):
    detalle_venta = get_object_or_404(DetalleVenta, id_DetVta=id)
    if request.method == 'POST':
        form = DetalleVentaForm(request.POST, instance=detalle_venta)
        if form.is_valid():
            form.save()
            return redirect('lista_detalles_ventas')
    else:
        form = DetalleVentaForm(instance=detalle_venta)
    return render(request, 'detalles_ventas/crear_detalle_venta.html', {'form': form})

# Eliminar un detalle de venta
def eliminar_detalle_venta(request, id):
    detalle_venta = get_object_or_404(DetalleVenta, id_DetVta=id)
    if request.method == 'POST':
        detalle_venta.delete()
        return redirect('lista_detalles_ventas')
    return render(request, 'detalles_ventas/eliminar_detalle_venta.html', {'detalle_venta': detalle_venta})


def lista_tipo_personas(request):
    tipo_personas = TipoPersona.objects.all()
    return render(request, 'tipo_personas/lista_tipo_personas.html', {'tipo_personas': tipo_personas})

def crear_tipo_persona(request):
    if request.method == 'POST':
        form = TipoPersonaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_tipo_personas')
    else:
        form = TipoPersonaForm()
    return render(request, 'tipo_personas/crear_tipo_persona.html', {'form': form})
def actualizar_tipo_persona(request, id):
    tipo_persona = get_object_or_404(TipoPersona, id_Tipo=id)
    if request.method == 'POST':
        form = TipoPersonaForm(request.POST, instance=tipo_persona)
        if form.is_valid():
            form.save()
            return redirect('lista_tipo_personas')
    else:
        form = TipoPersonaForm(instance=tipo_persona)
    return render(request, 'tipo_personas/crear_tipo_persona.html', {'form': form})

def eliminar_tipo_persona(request, id):
    tipo_persona = get_object_or_404(TipoPersona, id_Tipo=id)
    if request.method == 'POST':
        tipo_persona.delete()
        return redirect('lista_tipo_personas')
    return render(request, 'tipo_personas/eliminar_tipo_persona.html', {'tipo_persona': tipo_persona})
